import 'package:flutter/material.dart';
import 'package:todo_app/features/tasks/domain/entities/tasks.dart';

class TaskListWidget extends StatelessWidget {
  final List<Tasks> tasks;

  const TaskListWidget({super.key, required this.tasks});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: tasks.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: Text(tasks[index].id.toString()),
            title: Text(tasks[index].title.toString()),
            subtitle: Text(tasks[index].body.toString()),
            contentPadding: EdgeInsets.symmetric(horizontal: 10),
            onTap: () {},
          );
        });
  }
}
