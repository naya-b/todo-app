import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:todo_app/core/widgets/loading_widget.dart';
import 'package:todo_app/features/tasks/presentation/manager/bloc/task/tasks_bloc.dart';
import 'package:todo_app/features/tasks/presentation/widgets/message_display_widget.dart';
import 'package:todo_app/features/tasks/presentation/widgets/task_list_widget.dart';
import 'package:todo_app/test.dart';

class TasksPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('Todo'),
      ),
      body: _buildBody(),
      floatingActionButton: _buildFloatingBtn(),
    );
  }
}

Widget _buildFloatingBtn() {
  return FloatingActionButton(
    onPressed: () {},
    child: Icon(Icons.add),
  );
}

Widget _buildBody() {
  return Padding(
    padding: EdgeInsets.all(10),
    child: BlocBuilder<TasksBloc, TasksState>(
      builder: (context, state) {
        if (state is LoadingTasksState) {
          return LoadingWidget();
        } else if (state is LoadedTasksState) {
          return TaskListWidget(tasks: state.tasks);
        } else if (state is ErrorTasksState) {
          return MessageDisplayWidget(message: state.message);
        }

        // return LoadingWidget();
        return Test();
      },
    ),
  );
}
