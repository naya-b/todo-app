const String SERVER_FAILURE_MESSAGE = 'Please try again later .';
const String OFFLINE_FAILURE_MESSAGE = 'Please Check your Internet Connection';
const String EMPTY_CACHE_FAILURE_MESSAGE = 'NO Data';
