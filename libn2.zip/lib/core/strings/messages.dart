const ADD_SUCCESS_MESSAGE = 'Task Added Successfully';
const DELETE_SUCCESS_MESSAGE = 'Task Delete Successfully';
const UPDATE_SUCCESS_MESSAGE = 'Task Update Successfully';
