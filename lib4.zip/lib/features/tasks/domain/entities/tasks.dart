import 'package:equatable/equatable.dart';

class Tasks extends Equatable {
  final int id;
  final String title;
  final String body;
  final bool? isDone;
  final String createdBy;
  const Tasks({
    required this.id,
    required this.title,
    required this.body,
    required this.isDone,
    required this.createdBy,
  });
  @override
  // TODO: implement props
  List<Object?> get props => [id, title, body, isDone, createdBy];
}
