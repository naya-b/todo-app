import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:todo_app/features/tasks/domain/entities/tasks.dart';
import 'package:todo_app/features/tasks/presentation/manager/bloc/add_delete_update_tasks/add_delete_update_tasks_bloc.dart';

class FormWidget extends StatefulWidget {
  final bool isUpdate;
  final Tasks? task;

  const FormWidget({
    super.key,
    required this.isUpdate,
    this.task,
  });

  @override
  State<FormWidget> createState() => _FormWidgetState();
}

class _FormWidgetState extends State<FormWidget> {
  final _formKey = GlobalKey<FormState>();
  TextEditingController _titleController = TextEditingController();
  TextEditingController _bodyController = TextEditingController();

  _FormWidgetState();

  @override
  void initState() {
    if (widget.isUpdate) {
      _titleController.text = widget.task!.title;
      _bodyController.text = widget.task!.body;
    }
    super.initState();
  }

  void validateFormthenAddOrUpdateTask() {
    print('in validate function');
    final isValid = _formKey.currentState!.validate();
    if (isValid) {
      print('here in is valis');

      final task = Tasks(
        id: 0, // i will delete this from app write
        title: _titleController.text,
        body: _bodyController.text,
        isDone: widget.isUpdate ? widget.task!.isDone : false,
        createdBy: widget.isUpdate ? widget.task!.createdBy :'',
      );

      if (widget.isUpdate) {
        BlocProvider.of<AddDeleteUpdateTasksBloc>(context)
            .add(UpdateTaskEvent(tasks: task));
      } else {
        BlocProvider.of<AddDeleteUpdateTasksBloc>(context)
            .add(AddTaskEvent(tasks: task));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          TextFormField(
            controller: _titleController,
            validator: (val) => val!.isEmpty ? "Title Can't be empty" : null,
            decoration: InputDecoration(
                labelText: 'Title', border: UnderlineInputBorder()),
            // minLines: 1,
            // maxLines: 1,
          ),
          SizedBox(
            height: 8.0,
          ),
          TextFormField(
            controller: _bodyController,
            validator: (val) => val!.isEmpty ? "Body Can't be empty" : null,
            decoration: InputDecoration(
                labelText: 'Body', border: UnderlineInputBorder()),
            // minLines: 1,
            // maxLines: 3,
          ),
          SizedBox(
            height: 8.0,
          ),
          ElevatedButton.icon(
            onPressed: validateFormthenAddOrUpdateTask,
            icon: widget.isUpdate ? Icon(Icons.edit) : Icon(Icons.add),
            label: Text(widget.isUpdate ? 'Update' : 'Add'),
          ),
        ],
      ),
    );
  }
}
