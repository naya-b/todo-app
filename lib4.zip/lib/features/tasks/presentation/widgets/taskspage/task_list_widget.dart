import 'package:flutter/material.dart';
import 'package:todo_app/core/theems/color_theme.dart';
import 'package:todo_app/features/tasks/domain/entities/tasks.dart';
import 'package:todo_app/features/tasks/presentation/pages/add_update_task_page.dart';

class TaskListWidget extends StatelessWidget {
  final List<Tasks> tasks;

  const TaskListWidget({super.key, required this.tasks});

  // @override
  // Widget build(BuildContext context) {
  //   return ListView.builder(
  //       itemCount: tasks.length,
  //       itemBuilder: (context, index) {
  //         return ListTile(
  //           leading: Text(tasks[index].id.toString()),
  //           title: Text(tasks[index].title.toString()),
  //           subtitle: Text(tasks[index].body.toString()),
  //           contentPadding: EdgeInsets.symmetric(horizontal: 10),
  //           onTap: () {},
  //         );
  //       });
  // }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        itemCount: tasks.length,
        itemBuilder: (context, index) {
          return Card(
            elevation: 8.0,
            margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 6.0),
            child: Container(
              decoration: BoxDecoration(
                color: colorblue,
              ),
              child: ListTile(
                leading: Checkbox(
                  onChanged: (bool? value) {},
                  value: false,
                ),
                title: Text(
                  tasks[index].title.toString(),
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                    fontSize: 20.0,
                  ),
                ),
                subtitle: Text(
                  tasks[index].body.toString(),
                  style: TextStyle(color: Colors.black, fontSize: 15.0),
                ),
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                onTap: () => showDialog(
                  context: context,
                  builder: (context) => AddUpdateTaskPage(
                    isUpdate: true,
                    task: tasks[index],
                  ),
                ),
              ),
            ),
          );
        });
  }
}

// leading:  Text(
// (index + 1).toString() ,
// style: TextStyle(
// color: Colors.white,
// fontWeight: FontWeight.bold,
// fontSize: 20.0),
// ),
