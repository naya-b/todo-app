class Auth {
  final String? name;
  final String email;
  final String password;
  const Auth({this.name, required this.email, required this.password});
}
