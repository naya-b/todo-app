import 'package:flutter/material.dart';

const colorblue = Color(0xFF68caf2);
const colorgray = Color(0xFF525463);
const colororange = Color(0xFFf6ac48);
