import 'package:appwrite/appwrite.dart';
import 'package:dartz/dartz.dart';
import 'package:todo_app/features/authentecation/data/models/auth_model.dart';

Client client = Client()
    .setEndpoint('https://cloud.appwrite.io/v1')
    .setProject('6550991fddf45e3c1d2e')
    .setSelfSigned(status: true);

abstract class AuthRemoteDataSource {
  Future<bool> createUser(AuthModel authModel);
  Future<bool> loginUser(AuthModel authModel);
  Future<Unit> logoutUser();
  Future<bool> checkUserAuth();
}

class AuthRemoteDataSourceImpl implements AuthRemoteDataSource {
  final Account account;

  AuthRemoteDataSourceImpl(this.account);

  @override
  Future<bool> createUser(AuthModel authModel) async {
    try {
      final user = await account.create(
        userId: ID.unique(),
        email: authModel.email,
        password: authModel.password,
        name: authModel.name,
      );
      return true;
    } catch (e) {
      print(e);
      return false;
    }
  }

  @override
  Future<bool> loginUser(AuthModel authModel) async {
    try {
      final user = await account.createEmailSession(
          email: authModel.email, password: authModel.password);
      return true;
    } catch (e) {
      print(e);
      return false;
    }
  }

  @override
  Future<Unit> logoutUser() async {
    await account.deleteSession(sessionId: 'current');

    return Future.value(unit);
  }

  @override
  Future<bool> checkUserAuth() async {
    try {
      await account.getSession(sessionId: 'current');
      return true;
    } catch (e) {
      print(e);
      return false;
    }
  }
}
